package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{
	//our hash method
	public static String calculateHash(String name) throws NoSuchAlgorithmException{
		
		//message digest object using SHA-256 encryption
    	MessageDigest md = MessageDigest.getInstance("SHA-256");
    	byte[] hash = md.digest(name.getBytes(StandardCharsets.UTF_8));
    	BigInteger hex = new BigInteger(1, hash);
    	
    	//builds checksum string to display
    	StringBuilder checksum = new StringBuilder(hex.toString(16));
    	while (checksum.length() < 32) {
    		checksum.insert(0,'0');
    	} 
    	return checksum.toString();
	}
   
	
	@RequestMapping("/hash")
    public String myHash() throws Exception{
		//our data
    	String data = "Hello World Check Sum!";       
    	//calling our method
    	String hash = calculateHash(data);
        return "<p>data: "+ data + ": Check Sum Value: " + hash;
    }
}